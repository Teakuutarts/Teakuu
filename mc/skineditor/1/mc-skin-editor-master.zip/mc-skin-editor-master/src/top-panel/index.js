import TopPanel from './top-panel';

export default TopPanel;