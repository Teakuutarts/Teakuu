import SkinLayer from './skin-layer';

export default SkinLayer;