import Redactor from './redactor';

export default Redactor;