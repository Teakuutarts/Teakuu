import React from 'react';

import './app-header.css';

const AppHeader = () => {
    return (
            <h5 className="app-header">MC SKIN EDITOR v0</h5>
    )
};

export default AppHeader;