import SkinLayers from './skin-layers';

export default SkinLayers;