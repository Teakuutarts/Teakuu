class Setting{
	constructor(name, defaultValue){
		this.name = name;
		this.defaultValue = defaultValue;
	}
}